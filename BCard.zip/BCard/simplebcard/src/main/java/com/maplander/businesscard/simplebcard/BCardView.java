package com.maplander.businesscard.simplebcard;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class BCardView extends LinearLayout implements View.OnClickListener {
    private BCard bCard;
    private ImageView ivProfile, ivShare, ivIconPhone, ivIconEmail, ivIconWebsite;
    private TextView tvCompany, tvName, tvPhone, tvEmail, tvWebsite;
    private BusinessCardListener listener;

    public interface BusinessCardListener{
        void onShareBcClicked();
    }

    public BCardView(Context context) {
        super(context);
        init(context);
    }

    public BCardView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    private void init(Context context){
        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.layout_bcard_view, this);
        ivProfile=findViewById(R.id.BusinessCardView_ivProfileImage);
        tvCompany=findViewById(R.id.BusinessCardView_tvCompany);
        tvName=findViewById(R.id.BusinessCardView_tvName);
        ivIconPhone =findViewById(R.id.BusinessCardView_ivPhone);
        tvPhone=findViewById(R.id.BusinessCardView_tvPhone);
        ivIconEmail=findViewById(R.id.BusinessCardView_ivEmail);
        tvEmail=findViewById(R.id.BusinessCardView_tvEmail);
        ivIconWebsite=findViewById(R.id.BusinessCardView_ivWebSite);
        tvWebsite=findViewById(R.id.BusinessCardView_tvWebsite);
        ivShare=findViewById(R.id.BusinessCardView_ivShareCard);
        ivShare.setOnClickListener(this);
        listener=(BusinessCardListener) getContext();
    }

    @Override
    public void onClick(View v) {

    }

    public void load(BCard bCard){
        this.bCard=bCard;
    }
}
