package com.maplander.businesscard.simplebcard;

public class BCard {
    private String countryCode;
    private String backgroundImage;
    private String cardThumbnail;
    private Elem name;
    private Elem email;
    private Elem lastName;
    private Elem whatsApp;
    private Elem companyName;
    private Elem webSite;
    private Elem workPosition;
    private Elem logo;

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getBackgroundImage() {
        return backgroundImage;
    }

    public void setBackgroundImage(String backgroundImage) {
        this.backgroundImage = backgroundImage;
    }

    public String getCardThumbnail() {
        return cardThumbnail;
    }

    public void setCardThumbnail(String cardThumbnail) {
        this.cardThumbnail = cardThumbnail;
    }

    public Elem getName() {
        return name;
    }

    public void setName(Elem name) {
        this.name = name;
    }

    public Elem getEmail() {
        return email;
    }

    public void setEmail(Elem email) {
        this.email = email;
    }

    public Elem getLastName() {
        return lastName;
    }

    public void setLastName(Elem lastName) {
        this.lastName = lastName;
    }

    public Elem getWhatsApp() {
        return whatsApp;
    }

    public void setWhatsApp(Elem whatsApp) {
        this.whatsApp = whatsApp;
    }

    public Elem getCompanyName() {
        return companyName;
    }

    public void setCompanyName(Elem companyName) {
        this.companyName = companyName;
    }

    public Elem getWebSite() {
        return webSite;
    }

    public void setWebSite(Elem webSite) {
        this.webSite = webSite;
    }

    public Elem getWorkPosition() {
        return workPosition;
    }

    public void setWorkPosition(Elem workPosition) {
        this.workPosition = workPosition;
    }

    public Elem getLogo() {
        return logo;
    }

    public void setLogo(Elem logo) {
        this.logo = logo;
    }
}
